(() => {
  "use strict";
  var __webpack_exports__ = {};
  const ENDPOINT = "https://addons.mozilla.org/api/v5/addons/addon/erp-auto-login-iitkgp";
  function fetchVersionHistory() {
    const requestURL = `${ENDPOINT}/versions/?page_size=1`;
    const requestHeaders = new Headers;
    requestHeaders.append("Content-type", "application/json");
    const driveRequest = new Request(requestURL, {
      method: "GET",
      headers: requestHeaders
    });
    return fetch(driveRequest).then((response => {
      if (response.ok && response.status === 200) {
        return response.json();
      }
      throw response.status;
    }));
  }
  const fetchUpdate = async (currentVersion = "1.0") => {
    const {results} = await fetchVersionHistory();
    if (results[0].version === currentVersion) {
      return {
        type: "success",
        message: "You are on latest update!"
      };
    }
    return {
      type: "warning",
      message: `Update Available - ${results[0].version}`,
      update: results[0]
    };
  };
  function messageHandler(request, sender, sendResponse) {
    if (request.action === "update_check") {
      return fetchUpdate(browser.runtime.getManifest().version).then((res => ({
        ...res,
        action: request.action
      })));
    }
  }
  browser.runtime.onMessage.addListener(messageHandler);
})();