(() => {
  "use strict";
  var __webpack_exports__ = {};
  function getSecurityQues(username) {
    const params = `user_id=${username}`;
    const requestURL = "https://erp.iitkgp.ac.in/SSOAdministration/getSecurityQues.htm";
    const requestHeaders = new Headers;
    requestHeaders.append("Content-type", "application/x-www-form-urlencoded");
    const driveRequest = new Request(requestURL, {
      method: "POST",
      headers: requestHeaders,
      body: params
    });
    return fetch(driveRequest).then((response => {
      if (response.ok && response.status === 200) {
        return response.text();
      }
      throw response.status;
    }));
  }
  const usernameInput = document.querySelector("#username");
  const passwordInput = document.querySelector("#password");
  const _a1 = document.querySelector("#a1");
  const _a2 = document.querySelector("#a2");
  const _a3 = document.querySelector("#a3");
  const log = document.getElementById("log");
  const logClass = document.getElementById("log-class");
  const logIcon = document.getElementById("log-icon");
  const themeBtn = document.getElementById("theme");
  const themeInfo = document.getElementById("theme-info");
  const auto = document.getElementById("auto-login");
  const autoInfo = document.getElementById("auto-login-info");
  const popup_reset = document.getElementById("reset");
  const updateBtn = document.getElementById("update");
  const updateInfo = document.getElementById("update-info");
  document.getElementById("copyright").textContent = `Copyright©${(new Date).getFullYear()}`;
  document.getElementById("ext-version").textContent = browser.runtime.getManifest().version;
  document.oncontextmenu = () => false;
  const hIcon = document.getElementById("form-header-icon");
  const closeForm = document.getElementById("form-done");
  const mBtn = document.getElementById("maximize-btn");
  const panelContainer = document.getElementById("panel-container");
  closeForm.onclick = () => {
    document.body.classList.toggle("all-set");
    if (document.body.classList.contains("all-set")) {
      panelContainer.style.display = "flex";
    } else {
      panelContainer.style.display = "none";
    }
  };
  mBtn.onclick = () => {
    document.body.classList.toggle("all-set");
    if (document.body.classList.contains("all-set")) {
      panelContainer.style.display = "flex";
    } else {
      panelContainer.style.display = "none";
    }
  };
  document.querySelectorAll(".quick-link").forEach((element => {
    element.addEventListener("click", (() => {
      setTimeout((() => {
        window.close();
      }), 10);
    }));
  }));
  function storeSettings() {
    browser.storage.local.set({
      authCredentials: {
        username: usernameInput.value,
        password: passwordInput.value,
        q1: _a1.placeholder,
        a1: _a1.value,
        q2: _a2.placeholder,
        a2: _a2.value,
        q3: _a3.placeholder,
        a3: _a3.value,
        dark: themeBtn.checked,
        autoLogin: auto.checked
      }
    });
  }
  function logger(message, iconId = "info") {
    log.textContent = message;
    logClass.className = iconId;
    logIcon.setAttribute("href", browser.runtime.getURL(`/assets/icons.svg#${iconId}`));
  }
  function updateUI(restoredSettings) {
    const {authCredentials} = restoredSettings;
    if (!authCredentials.dark) {
      document.body.className = "";
      themeBtn.checked = false;
      themeInfo.textContent = "off";
    } else {
      themeInfo.textContent = "on";
      themeBtn.checked = true;
      hIcon.setAttribute("src", browser.runtime.getURL("/assets/images/header_icon_light.png"));
      document.body.className = "dark";
    }
    auto.checked = authCredentials.autoLogin;
    if (authCredentials.autoLogin) {
      autoInfo.textContent = "on";
    } else {
      autoInfo.textContent = "off";
    }
    if (authCredentials.username !== "" && authCredentials.password !== "" && authCredentials.q1 !== "loading" && authCredentials.q2 !== "loading" && authCredentials.q3 !== "loading" && authCredentials.a1 !== "" && authCredentials.a2 !== "" && authCredentials.a3 !== "") {
      document.body.classList.toggle("all-set");
      if (document.body.classList.contains("all-set")) {
        panelContainer.style.display = "flex";
      } else {
        panelContainer.style.display = "none";
      }
    }
    usernameInput.value = authCredentials.username || "";
    passwordInput.value = authCredentials.password || "";
    _a1.value = authCredentials.a1 || "";
    _a2.value = authCredentials.a2 || "";
    _a3.value = authCredentials.a3 || "";
    _a1.placeholder = authCredentials.q1 || "loading";
    _a2.placeholder = authCredentials.q2 || "loading";
    _a3.placeholder = authCredentials.q3 || "loading";
    if (authCredentials.username === "") {
      logger("Enter Roll Number");
    } else if (authCredentials.password === "") {
      logger("Enter Password", "warning");
      passwordInput.removeAttribute("disabled");
      passwordInput.addEventListener("keyup", (() => {
        _a1.removeAttribute("disabled");
        _a2.removeAttribute("disabled");
        _a3.removeAttribute("disabled");
        logger("Enter security answers!", "warning");
      }));
      passwordInput.removeEventListener("keyup", null);
    } else if (_a1.value !== "" && _a2.value !== "" && _a3.value !== "") {
      _a1.setAttribute("disabled", true);
      _a2.setAttribute("disabled", true);
      _a3.setAttribute("disabled", true);
      logger(`You are all set! ${authCredentials.username}`, "check");
    } else {
      logger("Fill security answers!", "warning");
      _a1.removeAttribute("disabled");
      _a2.removeAttribute("disabled");
      _a3.removeAttribute("disabled");
    }
  }
  async function getQuestions(cb) {
    if (_a1.placeholder !== "loading" && _a2.placeholder !== "loading" && _a3.placeholder !== "loading") {
      return cb("Question already loaded!", true);
    }
    function httpCallback(message, done) {
      if (done) {
        if (_a1.placeholder === "loading" || _a2.placeholder === "loading" || _a3.placeholder === "loading") {
          return cb("Re call getquestion", false);
        }
        return cb("Got all Questions!", true);
      }
      logger(message, "cross");
    }
    const q = await getSecurityQues(usernameInput.value);
    if (q !== "FALSE") {
      passwordInput.removeAttribute("disabled");
      if (_a1.placeholder === "loading") {
        _a1.placeholder = q;
        _a1.removeAttribute("disabled");
      } else if (_a2.placeholder === "loading" && q !== _a1.placeholder) {
        _a2.placeholder = q;
        _a2.removeAttribute("disabled");
      } else if (q !== _a1.placeholder && q !== _a2.placeholder) {
        _a3.placeholder = q;
        _a3.removeAttribute("disabled");
      }
      return httpCallback("Got a Question", true);
    }
    return httpCallback("Roll No does not exist, Retry!", false);
  }
  function questionsCallback(message, done) {
    if (done) {
      if (passwordInput.value === "") {
        logger(`${message} Fill required info.`, "check");
      } else if (_a1.value === "" || _a2.value === "" || _a3.value === "") {
        logger("Fill Security Answers", "warning");
      } else {
        logger("All Set!", "check");
      }
      storeSettings();
    } else {
      getQuestions(questionsCallback);
    }
  }
  function onError(e) {
    console.error(e);
  }
  function checkStoredSettings(storedSettings) {
    if (!storedSettings.authCredentials) {
      const authCredentials = {
        username: "",
        password: "",
        q1: "loading",
        q2: "loading",
        q3: "loading",
        a1: "",
        a2: "",
        a3: "",
        dark: false,
        autoLogin: true
      };
      browser.storage.local.set({
        authCredentials
      }).then((() => updateUI({
        authCredentials
      })), onError);
    } else {
      updateUI(storedSettings);
    }
  }
  function resetHandler() {
    const actionBtnYes = document.createElement("div");
    actionBtnYes.className = "action";
    actionBtnYes.textContent = "Yes";
    const actionBtnCancel = document.createElement("div");
    actionBtnCancel.className = "action";
    actionBtnCancel.textContent = "Cancel";
    logClass.appendChild(actionBtnYes);
    logClass.appendChild(actionBtnCancel);
    logger("Are you sure!", "warning");
    popup_reset.setAttribute("disabled", true);
    actionBtnYes.onclick = () => {
      popup_reset.removeAttribute("disabled");
      logClass.removeChild(actionBtnYes);
      logClass.removeChild(actionBtnCancel);
      usernameInput.value = "";
      passwordInput.value = "";
      _a1.value = "";
      _a2.value = "";
      _a3.value = "";
      _a1.placeholder = "loading";
      _a2.placeholder = "loading";
      _a3.placeholder = "loading";
      passwordInput.setAttribute("disabled", true);
      _a1.setAttribute("disabled", true);
      _a2.setAttribute("disabled", true);
      _a3.setAttribute("disabled", true);
      browser.storage.local.set({
        authCredentials: {
          username: "",
          password: "",
          q1: "loading",
          q2: "loading",
          q3: "loading",
          a1: "",
          a2: "",
          a3: "",
          dark: false,
          autoLogin: true
        }
      }).then((() => {
        logger("Data Cleared!", "check");
        browser.tabs.create({
          url: "https://erp.iitkgp.ac.in/IIT_ERP3/logout.htm"
        }).then((() => {
          console.log("Successfully logged Out!");
        }), onError);
      }));
    };
    actionBtnCancel.onclick = () => {
      popup_reset.removeAttribute("disabled");
      logClass.removeChild(actionBtnYes);
      logClass.removeChild(actionBtnCancel);
      logger("Cancelled!");
    };
  }
  function toggleDark() {
    if (document.body.classList.contains("dark")) {
      themeInfo.textContent = "off";
      hIcon.setAttribute("src", browser.runtime.getURL("/assets/images/header_icon.png"));
    } else {
      themeInfo.textContent = "on";
      hIcon.setAttribute("src", browser.runtime.getURL("/assets/images/header_icon_light.png"));
    }
    document.body.classList.toggle("dark");
  }
  function updateCheckBox(curr, id) {
    const {authCredentials} = curr;
    if (id === "theme") {
      browser.storage.local.set({
        authCredentials: {
          ...authCredentials,
          dark: !authCredentials.dark
        }
      });
      toggleDark();
    } else if (id === "auto-login") {
      browser.storage.local.set({
        authCredentials: {
          ...authCredentials,
          autoLogin: !authCredentials.autoLogin
        }
      });
      if (authCredentials.autoLogin) {
        autoInfo.textContent = "off";
      } else autoInfo.textContent = "on";
    }
  }
  function handleMessageResponse(response) {
    if (response.action === "update_check") {
      const {update, message, type} = response;
      updateInfo.textContent = "";
      document.getElementById("update-btn").textContent = message;
      if (update) {
        document.getElementById("update-default-icon").style.display = "none";
        document.getElementById("update-found-icon").style.display = "block";
        document.getElementById("update-btn").setAttribute = "disabled";
        const whatsnew = document.createElement("p");
        whatsnew.id = "update_checked";
        whatsnew.className = "panel-card-label";
        whatsnew.innerText = update.release_notes["en-US"];
        document.getElementById("panel-update").appendChild(whatsnew);
      } else {
        document.getElementById("update-default-icon").style.display = "none";
        document.getElementById("no-update-found-icon").style.display = "block";
      }
    }
  }
  function testRoll() {
    if (usernameInput.value.length !== 9) {
      if (usernameInput.value.length === 8 || usernameInput.value.length === 10) {
        _a1.placeholder = "loading";
        _a2.placeholder = "loading";
        _a3.placeholder = "loading";
        _a1.value = "";
        _a2.value = "";
        _a3.value = "";
        passwordInput.value = "";
      }
      logger("Enter a valid Roll No", "cross");
      return;
    }
    const re = /[0-9]{2}[a-z|A-Z]{2}[0-9|a-z|A-Z]{1}[a-z|A-Z|0-9]{2}[0-9]{2}/;
    const OK = re.exec(usernameInput.value);
    if (!OK) {
      logger("Enter a valid Roll No", "cross");
    } else {
      logger("Getting Questions..", "warning");
      getQuestions(questionsCallback);
    }
  }
  function messageTab(action, msg = "") {
    const sending = browser.runtime.sendMessage({
      action,
      query: msg
    });
    sending.then(handleMessageResponse, (err => console.log(`Error: ${err}`)));
  }
  browser.storage.local.get().then(checkStoredSettings, onError);
  popup_reset.addEventListener("click", resetHandler);
  usernameInput.addEventListener("keyup", testRoll);
  passwordInput.addEventListener("blur", storeSettings);
  _a1.addEventListener("blur", storeSettings);
  _a2.addEventListener("blur", storeSettings);
  _a3.addEventListener("blur", storeSettings);
  auto.onclick = () => {
    const getData = browser.storage.local.get();
    getData.then((data => updateCheckBox(data, "auto-login")));
  };
  themeBtn.onclick = () => {
    const getData = browser.storage.local.get();
    getData.then((data => updateCheckBox(data, "theme")));
  };
  updateBtn.onclick = () => {
    if (document.getElementById("update_checked")) {
      document.getElementById("update_checked").remove();
      updateInfo.textContent = "checking..";
      messageTab("update_check");
    } else {
      updateInfo.textContent = "checking..";
      messageTab("update_check");
    }
  };
})();